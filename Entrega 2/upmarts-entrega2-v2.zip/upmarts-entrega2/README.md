# UPM Arts - Entrega 2

Implementación Java/Maven del subconjunto de funcionalidades de alta y acceso de usuarios.

## Cómo abrirlo en Eclipse

1. Descomprimir el ZIP.
2. En Eclipse: File > Import > Maven > Existing Maven Projects.
3. Seleccionar la carpeta `upmarts-entrega2`.
4. Ejecutar `upmarts.App` como Java Application.

## Administrador inicial

Correo: `admin@upm.es`
Contraseña: `Admin123456A`

## Persistencia

Los usuarios se guardan en `data/usuarios.txt`, una línea por usuario y atributos separados por `;`.

## ExternalLDAP

El adaptador LDAP está en `upmarts.integracion.AdaptadorLDAP`.
Si se añade `externals-5.1.jar` al build path, el adaptador intenta localizar `ExternalLDAP` por reflexión.
Si no está la librería, usa una validación local mínima para poder ejecutar la práctica en Eclipse.

## Validación de términos conflictivos

La validación del nick no usa una lista fija en código. La clase `Usuario` lee los términos conflictivos desde:

- `data/terminos_conflictivos.txt`, cuando se ejecuta desde el proyecto.
- `src/main/resources/terminos_conflictivos.txt`, como recurso incluido en el `.jar`.

Se ignoran líneas vacías y líneas que empiezan por `#`. La comparación se hace en minúsculas y por coincidencia exacta del nick con el término prohibido.
