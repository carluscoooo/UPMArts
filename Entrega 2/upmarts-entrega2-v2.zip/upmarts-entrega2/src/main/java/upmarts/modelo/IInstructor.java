package upmarts.modelo;

public interface IInstructor {
    String getIBAN();
    void setIBAN(String IBAN);
    boolean darseDeBaja();
}
