package upmarts.modelo;

public class EstudianteUPM extends MiembroUPM {

    private String numeroMatricula;

    public EstudianteUPM(String nombreUsuario, String nombreCompleto, String correoElectronico,
                         String pass, String DNI, String tarjeta, String numeroMatricula) {
        super(nombreUsuario, nombreCompleto, correoElectronico, pass, DNI, tarjeta, "ESTUDIANTE");
        this.numeroMatricula = numeroMatricula;
    }

    public String getNumeroMatricula() {
        return numeroMatricula;
    }

    public void setNumeroMatricula(String numeroMatricula) {
        this.numeroMatricula = numeroMatricula;
    }

    @Override
    public TipoUsuario getTipoUsuario() {
        return TipoUsuario.ESTUDIANTE_UPM;
    }
}
