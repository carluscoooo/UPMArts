package upmarts.modelo;

public abstract class UsuarioConDNI extends Usuario {

    private String DNI;

    public UsuarioConDNI(String nombreUsuario, String nombreCompleto, String correoElectronico, String pass, String DNI) {
        super(nombreUsuario, nombreCompleto, correoElectronico, pass);
        this.DNI = DNI;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }
}
