package upmarts.modelo;

public class ParticipanteExterno extends UsuarioConDNI implements IParticipanteExterno {

    private String tarjetaCredito;

    public ParticipanteExterno(String nombreUsuario, String nombreCompleto, String correoElectronico,
                               String pass, String DNI, String tarjeta) {
        super(nombreUsuario, nombreCompleto, correoElectronico, pass, DNI);
        this.tarjetaCredito = tarjeta;
    }

    public String getTarjetaCredito() {
        return tarjetaCredito;
    }

    public void setTarjetaCredito(String tarjeta) {
        this.tarjetaCredito = tarjeta;
    }

    public boolean darseDeBaja() {
        return true;
    }

    @Override
    public TipoUsuario getTipoUsuario() {
        return TipoUsuario.EXTERNO;
    }
}
