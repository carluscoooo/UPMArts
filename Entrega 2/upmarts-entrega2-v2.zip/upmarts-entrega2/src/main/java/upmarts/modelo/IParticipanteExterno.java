package upmarts.modelo;

public interface IParticipanteExterno {
    String getTarjetaCredito();
    void setTarjetaCredito(String tarjeta);
    boolean darseDeBaja();
}
