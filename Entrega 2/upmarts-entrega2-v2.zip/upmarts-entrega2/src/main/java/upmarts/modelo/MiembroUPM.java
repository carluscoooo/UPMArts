package upmarts.modelo;

public abstract class MiembroUPM extends UsuarioConDNI implements IMiembroUPM {

    private String tarjetaCredito;
    private String rolUPM;

    public MiembroUPM(String nombreUsuario, String nombreCompleto, String correoElectronico,
                      String pass, String DNI, String tarjeta, String rolUPM) {
        super(nombreUsuario, nombreCompleto, correoElectronico, pass, DNI);
        this.tarjetaCredito = tarjeta;
        this.rolUPM = rolUPM;
    }

    public String getTarjetaCredito() {
        return tarjetaCredito;
    }

    public void setTarjetaCredito(String tarjetaCredito) {
        this.tarjetaCredito = tarjetaCredito;
    }

    public String getRolUPM() {
        return rolUPM;
    }
}
