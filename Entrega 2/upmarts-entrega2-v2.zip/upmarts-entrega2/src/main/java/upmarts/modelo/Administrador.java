package upmarts.modelo;

public class Administrador extends Usuario implements IAdministrador {

    private String telefonoAdministrador;

    public Administrador(String nombreUsuario, String nombreCompleto, String correoElectronico,
                         String pass, String telefono) {
        super(nombreUsuario, nombreCompleto, correoElectronico, pass);
        this.telefonoAdministrador = telefono;
    }

    public String getTelefonoAdministrador() {
        return telefonoAdministrador;
    }

    public void setTelefonoAdministrador(String telefono) {
        this.telefonoAdministrador = telefono;
    }

    @Override
    public TipoUsuario getTipoUsuario() {
        return TipoUsuario.ADMINISTRADOR;
    }
}
