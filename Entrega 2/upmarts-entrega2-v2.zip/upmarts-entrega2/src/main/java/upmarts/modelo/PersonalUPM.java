package upmarts.modelo;

public class PersonalUPM extends MiembroUPM {

    private int antiguedad;

    public PersonalUPM(String nombreUsuario, String nombreCompleto, String correoElectronico,
                       String pass, String DNI, String tarjeta, String rolUPM, int antiguedad) {
        super(nombreUsuario, nombreCompleto, correoElectronico, pass, DNI, tarjeta, rolUPM);
        this.antiguedad = antiguedad;
    }

    public int getAntiguedad() {
        return antiguedad;
    }

    public void setAntiguedad(int antiguedad) {
        this.antiguedad = antiguedad;
    }

    @Override
    public TipoUsuario getTipoUsuario() {
        return TipoUsuario.PERSONAL_UPM;
    }
}
