package upmarts.modelo;

public enum TipoUsuario {
    EXTERNO,
    ESTUDIANTE_UPM,
    PERSONAL_UPM,
    INSTRUCTOR,
    ADMINISTRADOR
}
