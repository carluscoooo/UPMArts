package upmarts.modelo;

public class Instructor extends UsuarioConDNI implements IInstructor {

    private String IBAN;

    public Instructor(String nombreUsuario, String nombreCompleto, String correoElectronico,
                      String pass, String DNI, String IBAN) {
        super(nombreUsuario, nombreCompleto, correoElectronico, pass, DNI);
        this.IBAN = IBAN;
    }

    public String getIBAN() {
        return IBAN;
    }

    public void setIBAN(String IBAN) {
        this.IBAN = IBAN;
    }

    public boolean darseDeBaja() {
        return true;
    }

    @Override
    public TipoUsuario getTipoUsuario() {
        return TipoUsuario.INSTRUCTOR;
    }
}
