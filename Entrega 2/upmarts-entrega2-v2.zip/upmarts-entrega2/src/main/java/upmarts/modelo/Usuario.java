package upmarts.modelo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashSet;
import java.util.Set;

public abstract class Usuario {

    private String nombreUsuario;
    private String nombreCompleto;
    private String correoElectronico;
    private String password;

    private static final String NOMBRE_FICHERO_TERMINOS = "terminos_conflictivos.txt";
    private static Set<String> terminosConflictivos;

    public Usuario(String nombreUsuario, String nombreCompleto, String correoElectronico, String pass) {
        this.nombreUsuario = nombreUsuario;
        this.nombreCompleto = nombreCompleto;
        this.correoElectronico = correoElectronico;
        this.password = pass;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getContrasena() {
        return password;
    }

    public void setContrasena(String pass) {
        this.password = pass;
    }

    public static boolean validarNick(String nick) {
        if (nick == null) {
            return false;
        }

        String nickLimpio = nick.trim();

        if (nickLimpio.length() < 4 || nickLimpio.length() > 12) {
            return false;
        }

        if (!nickLimpio.matches("[A-Za-z0-9]+")) {
            return false;
        }

        String nickNormalizado = nickLimpio.toLowerCase();
        return !obtenerTerminosConflictivos().contains(nickNormalizado);
    }

    private static Set<String> obtenerTerminosConflictivos() {
        if (terminosConflictivos == null) {
            terminosConflictivos = cargarTerminosConflictivos();
        }
        return terminosConflictivos;
    }

    private static Set<String> cargarTerminosConflictivos() {
        Set<String> terminos = new HashSet<String>();

        if (cargarDesdeFicheroExterno(terminos)) {
            return terminos;
        }

        cargarDesdeRecursos(terminos);
        return terminos;
    }

    private static boolean cargarDesdeFicheroExterno(Set<String> terminos) {
        Path ruta = Paths.get("data", NOMBRE_FICHERO_TERMINOS);

        if (!Files.exists(ruta)) {
            return false;
        }

        try (BufferedReader lector = Files.newBufferedReader(ruta, StandardCharsets.UTF_8)) {
            leerTerminos(lector, terminos);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    private static void cargarDesdeRecursos(Set<String> terminos) {
        InputStream entrada = Usuario.class.getClassLoader().getResourceAsStream(NOMBRE_FICHERO_TERMINOS);

        if (entrada == null) {
            return;
        }

        try (BufferedReader lector = new BufferedReader(new InputStreamReader(entrada, StandardCharsets.UTF_8))) {
            leerTerminos(lector, terminos);
        } catch (IOException e) {
            terminos.clear();
        }
    }

    private static void leerTerminos(BufferedReader lector, Set<String> terminos) throws IOException {
        String linea;

        while ((linea = lector.readLine()) != null) {
            String termino = linea.trim().toLowerCase();

            if (!termino.isEmpty() && !termino.startsWith("#")) {
                terminos.add(termino);
            }
        }
    }

    public static boolean validarPassword(String pass) {
        if (pass == null || pass.length() < 12) {
            return false;
        }

        boolean tieneMayuscula = false;
        boolean tieneMinuscula = false;
        boolean tieneNumero = false;

        for (int i = 0; i < pass.length(); i++) {
            char c = pass.charAt(i);
            if (Character.isUpperCase(c)) {
                tieneMayuscula = true;
            } else if (Character.isLowerCase(c)) {
                tieneMinuscula = true;
            } else if (Character.isDigit(c)) {
                tieneNumero = true;
            }
        }

        return tieneMayuscula && tieneMinuscula && tieneNumero;
    }

    public static String cifrarPassword(String pass) {
        if (pass == null) {
            return "";
        }

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(pass.getBytes(StandardCharsets.UTF_8));
            StringBuilder resultado = new StringBuilder();

            for (byte b : hash) {
                String hexadecimal = Integer.toHexString(0xff & b);
                if (hexadecimal.length() == 1) {
                    resultado.append('0');
                }
                resultado.append(hexadecimal);
            }

            return resultado.toString();
        } catch (NoSuchAlgorithmException e) {
            return pass;
        }
    }

    public abstract TipoUsuario getTipoUsuario();

    @Override
    public String toString() {
        return getTipoUsuario() + " - " + nombreUsuario + " - " + nombreCompleto + " - " + correoElectronico;
    }
}
