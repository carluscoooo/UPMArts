package upmarts.modelo;

public interface IMiembroUPM {
    String getRolUPM();
    String getDNI();
    String getTarjetaCredito();
}
