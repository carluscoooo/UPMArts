package upmarts.vista;

public interface IVistaUsuariosCLI {
    void mostrarMenuUsuarios();
    String[] pedirDatosRegistroExterno();
    String[] pedirDatosRegistroUPM();
    String[] pedirCredencialesLogin();
    String[] pedirPreferenciasArtisticas();
}
