package upmarts.vista;

import java.util.Scanner;

public class VistaPrincipalCLI {

    private Scanner scanner;
    private IVistaUsuariosCLI vistaUsuariosCLI;

    public VistaPrincipalCLI(IVistaUsuariosCLI vistaUsuariosCLI) {
        this.scanner = new Scanner(System.in);
        this.vistaUsuariosCLI = vistaUsuariosCLI;
    }

    public VistaPrincipalCLI(IVistaUsuariosCLI vistaUsuariosCLI, Scanner scanner) {
        this.scanner = scanner;
        this.vistaUsuariosCLI = vistaUsuariosCLI;
    }

    public void iniciarAplicacion() {
        int opcion = -1;

        while (opcion != 0) {
            System.out.println("\n=================================");
            System.out.println("          UPM Arts CLI           ");
            System.out.println("=================================");
            System.out.println("1. Gestión de usuarios");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = leerEntero();

            if (opcion == 1) {
                vistaUsuariosCLI.mostrarMenuUsuarios();
            } else if (opcion != 0) {
                System.out.println("Opción no válida.");
            }
        }

        System.out.println("Aplicación finalizada.");
    }

    public int mostrarMenuInicio() {
        System.out.println("1. Gestión de usuarios");
        System.out.println("0. Salir");
        return leerEntero();
    }

    public int mostrarMenuAdministrador() {
        System.out.println("1. Dar de alta instructor");
        System.out.println("0. Cerrar sesión");
        return leerEntero();
    }

    public int mostrarMenuMiembroUPM() {
        System.out.println("Menú de miembro UPM no desarrollado en esta entrega.");
        return 0;
    }

    public int mostrarMenuParticipanteExterno() {
        System.out.println("Menú de participante externo no desarrollado en esta entrega.");
        return 0;
    }

    public int mostrarMenuInstructor() {
        System.out.println("Menú de instructor no desarrollado en esta entrega.");
        return 0;
    }

    private int leerEntero() {
        try {
            String texto = scanner.nextLine();
            return Integer.parseInt(texto.trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
