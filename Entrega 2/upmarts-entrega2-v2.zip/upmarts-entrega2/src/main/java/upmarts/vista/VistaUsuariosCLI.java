package upmarts.vista;

import java.util.Scanner;

import upmarts.controlador.IControladorUsuarios;
import upmarts.modelo.Administrador;
import upmarts.modelo.Usuario;

public class VistaUsuariosCLI implements IVistaUsuariosCLI {

    private Scanner scanner;
    private IControladorUsuarios controladorUsuarios;

    public VistaUsuariosCLI(IControladorUsuarios controladorUsuarios, Scanner scanner) {
        this.controladorUsuarios = controladorUsuarios;
        this.scanner = scanner;
    }

    public void mostrarMenuUsuarios() {
        int opcion = -1;

        while (opcion != 0) {
            System.out.println("\n--- Gestión de usuarios ---");
            System.out.println("1. Registrar participante externo");
            System.out.println("2. Registrar miembro UPM");
            System.out.println("3. Acceder al sistema");
            System.out.println("0. Volver");
            System.out.print("Seleccione una opción: ");

            opcion = leerEntero();

            if (opcion == 1) {
                registrarParticipanteExterno();
            } else if (opcion == 2) {
                registrarMiembroUPM();
            } else if (opcion == 3) {
                Usuario usuario = login();
                if (usuario != null) {
                    mostrarMenuSegunUsuario(usuario);
                }
            } else if (opcion != 0) {
                System.out.println("Opción no válida.");
            }
        }
    }

    public String[] pedirDatosRegistroExterno() {
        String[] datos = new String[6];

        System.out.println("\n--- Alta de participante externo ---");
        datos[0] = pedirTexto("Nombre completo: ");
        datos[1] = pedirTexto("Nick: ");
        datos[2] = pedirTexto("Correo electrónico: ");
        datos[3] = pedirTexto("Contraseña: ");
        datos[4] = pedirTexto("DNI: ");
        datos[5] = pedirTexto("Tarjeta de crédito/débito: ");

        return datos;
    }

    public String[] pedirDatosRegistroUPM() {
        String[] datos = new String[8];

        System.out.println("\n--- Alta de miembro UPM ---");
        datos[0] = pedirTexto("Nombre completo: ");
        datos[1] = pedirTexto("Nick: ");
        datos[2] = pedirTexto("Correo institucional UPM: ");
        datos[3] = pedirTexto("Contraseña: ");
        datos[4] = pedirTexto("DNI: ");
        datos[5] = pedirTexto("Tarjeta de crédito/débito: ");
        datos[6] = pedirTexto("Tipo UPM (ESTUDIANTE/PDI/PAS): ");

        if ("ESTUDIANTE".equalsIgnoreCase(datos[6].trim())) {
            datos[7] = pedirTexto("Número de matrícula: ");
        } else {
            datos[7] = pedirTexto("Antigüedad en años: ");
        }

        return datos;
    }

    public String[] pedirCredencialesLogin() {
        String[] datos = new String[2];

        System.out.println("\n--- Acceso al sistema ---");
        datos[0] = pedirTexto("Correo electrónico: ");
        datos[1] = pedirTexto("Contraseña: ");

        return datos;
    }

    public String[] pedirPreferenciasArtisticas() {
        String[] datos = new String[2];

        System.out.println("\n--- Preferencias artísticas ---");
        datos[0] = pedirTexto("Disciplina (música/pintura/teatro): ");
        datos[1] = pedirTexto("Nivel de experiencia (1-10): ");

        return datos;
    }

    private void registrarParticipanteExterno() {
        String[] datos = pedirDatosRegistroExterno();

        boolean registrado = controladorUsuarios.registrarParticipanteExterno(
                datos[0], datos[1], datos[2], datos[3], datos[4], datos[5]
        );

        if (registrado) {
            System.out.println("Participante externo registrado correctamente.");
        } else {
            System.out.println("No se pudo registrar el participante externo. Revise los datos introducidos.");
        }
    }

    private void registrarMiembroUPM() {
        String[] datos = pedirDatosRegistroUPM();

        boolean registrado = controladorUsuarios.registrarMiembroUPM(
                datos[0], datos[1], datos[2], datos[3], datos[4], datos[5], datos[6], datos[7]
        );

        if (registrado) {
            System.out.println("Miembro UPM registrado correctamente.");
        } else {
            System.out.println("No se pudo registrar el miembro UPM. Revise los datos introducidos.");
        }
    }

    private Usuario login() {
        String[] datos = pedirCredencialesLogin();
        Usuario usuario = controladorUsuarios.login(datos[0], datos[1]);

        if (usuario != null) {
            System.out.println("Acceso correcto. Usuario: " + usuario.getNombreCompleto());
        } else {
            System.out.println("Correo o contraseña incorrectos.");
        }

        return usuario;
    }

    private void mostrarMenuSegunUsuario(Usuario usuario) {
        if (usuario instanceof Administrador) {
            mostrarMenuAdministrador();
        } else {
            System.out.println("Tipo de usuario: " + usuario.getTipoUsuario());
            System.out.println("No hay más operaciones implementadas para este tipo de usuario en esta entrega.");
        }
    }

    private void mostrarMenuAdministrador() {
        int opcion = -1;

        while (opcion != 0) {
            System.out.println("\n--- Menú de administrador ---");
            System.out.println("1. Dar de alta instructor");
            System.out.println("2. Listar usuarios");
            System.out.println("0. Cerrar sesión");
            System.out.print("Seleccione una opción: ");

            opcion = leerEntero();

            if (opcion == 1) {
                registrarInstructor();
            } else if (opcion == 2) {
                listarUsuarios();
            } else if (opcion != 0) {
                System.out.println("Opción no válida.");
            }
        }
    }

    private void registrarInstructor() {
        System.out.println("\n--- Alta de instructor ---");
        String nombre = pedirTexto("Nombre completo: ");
        String nick = pedirTexto("Nick: ");
        String correo = pedirTexto("Correo electrónico: ");
        String pass = pedirTexto("Contraseña: ");
        String dni = pedirTexto("DNI: ");
        String iban = pedirTexto("IBAN: ");

        boolean registrado = controladorUsuarios.registrarInstructorUPM(nombre, nick, correo, pass, dni, iban);

        if (registrado) {
            System.out.println("Instructor registrado correctamente.");
        } else {
            System.out.println("No se pudo registrar el instructor. Revise los datos introducidos.");
        }
    }

    private void listarUsuarios() {
        System.out.println("\n--- Usuarios registrados ---");
        for (Usuario usuario : controladorUsuarios.obtenerUsuarios()) {
            System.out.println(usuario);
        }
    }

    private String pedirTexto(String mensaje) {
        System.out.print(mensaje);
        return scanner.nextLine().trim();
    }

    private int leerEntero() {
        try {
            String texto = scanner.nextLine();
            return Integer.parseInt(texto.trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
