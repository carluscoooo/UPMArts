package upmarts.persistencia;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import upmarts.modelo.Administrador;
import upmarts.modelo.EstudianteUPM;
import upmarts.modelo.Instructor;
import upmarts.modelo.ParticipanteExterno;
import upmarts.modelo.PersonalUPM;
import upmarts.modelo.TipoUsuario;
import upmarts.modelo.Usuario;

public class GestorFicheroUsuarios implements IAccesoUsuarios {

    private String rutaFichero;

    public GestorFicheroUsuarios() {
        this("data/usuarios.txt");
    }

    public GestorFicheroUsuarios(String rutaFichero) {
        this.rutaFichero = rutaFichero;
        prepararFichero();
    }

    private void prepararFichero() {
        try {
            File fichero = new File(rutaFichero);
            File carpeta = fichero.getParentFile();

            if (carpeta != null && !carpeta.exists()) {
                carpeta.mkdirs();
            }

            if (!fichero.exists()) {
                fichero.createNewFile();
            }
        } catch (IOException e) {
            System.out.println("No se pudo preparar el fichero de usuarios: " + e.getMessage());
        }
    }

    public void guardarUsuarios(List<Usuario> usuarios) {
        BufferedWriter writer = null;

        try {
            writer = new BufferedWriter(new FileWriter(rutaFichero, false));

            for (Usuario usuario : usuarios) {
                writer.write(convertirUsuarioALinea(usuario));
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error guardando usuarios: " + e.getMessage());
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    System.out.println("Error cerrando el fichero: " + e.getMessage());
                }
            }
        }
    }

    public List<Usuario> leerUsuarios() {
        List<Usuario> usuarios = new ArrayList<Usuario>();
        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new FileReader(rutaFichero));
            String linea;

            while ((linea = reader.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    Usuario usuario = convertirLineaAUsuario(linea);
                    if (usuario != null) {
                        usuarios.add(usuario);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error leyendo usuarios: " + e.getMessage());
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    System.out.println("Error cerrando el fichero: " + e.getMessage());
                }
            }
        }

        return usuarios;
    }

    private String convertirUsuarioALinea(Usuario usuario) {
        StringBuilder linea = new StringBuilder();
        linea.append(usuario.getTipoUsuario()).append(";");
        linea.append(limpiar(usuario.getNombreUsuario())).append(";");
        linea.append(limpiar(usuario.getNombreCompleto())).append(";");
        linea.append(limpiar(usuario.getCorreoElectronico())).append(";");
        linea.append(limpiar(usuario.getContrasena()));

        if (usuario instanceof ParticipanteExterno) {
            ParticipanteExterno externo = (ParticipanteExterno) usuario;
            linea.append(";").append(limpiar(externo.getDNI()));
            linea.append(";").append(limpiar(externo.getTarjetaCredito()));
        } else if (usuario instanceof EstudianteUPM) {
            EstudianteUPM estudiante = (EstudianteUPM) usuario;
            linea.append(";").append(limpiar(estudiante.getDNI()));
            linea.append(";").append(limpiar(estudiante.getTarjetaCredito()));
            linea.append(";").append(limpiar(estudiante.getNumeroMatricula()));
        } else if (usuario instanceof PersonalUPM) {
            PersonalUPM personal = (PersonalUPM) usuario;
            linea.append(";").append(limpiar(personal.getDNI()));
            linea.append(";").append(limpiar(personal.getTarjetaCredito()));
            linea.append(";").append(limpiar(personal.getRolUPM()));
            linea.append(";").append(personal.getAntiguedad());
        } else if (usuario instanceof Instructor) {
            Instructor instructor = (Instructor) usuario;
            linea.append(";").append(limpiar(instructor.getDNI()));
            linea.append(";").append(limpiar(instructor.getIBAN()));
        } else if (usuario instanceof Administrador) {
            Administrador administrador = (Administrador) usuario;
            linea.append(";").append(limpiar(administrador.getTelefonoAdministrador()));
        }

        return linea.toString();
    }

    private Usuario convertirLineaAUsuario(String linea) {
        String[] partes = linea.split(";", -1);

        if (partes.length < 5) {
            return null;
        }

        try {
            TipoUsuario tipo = TipoUsuario.valueOf(partes[0]);
            String nick = partes[1];
            String nombreCompleto = partes[2];
            String correo = partes[3];
            String password = partes[4];

            if (tipo == TipoUsuario.EXTERNO && partes.length >= 7) {
                return new ParticipanteExterno(nick, nombreCompleto, correo, password, partes[5], partes[6]);
            }

            if (tipo == TipoUsuario.ESTUDIANTE_UPM && partes.length >= 8) {
                return new EstudianteUPM(nick, nombreCompleto, correo, password, partes[5], partes[6], partes[7]);
            }

            if (tipo == TipoUsuario.PERSONAL_UPM && partes.length >= 9) {
                int antiguedad = convertirEntero(partes[8]);
                return new PersonalUPM(nick, nombreCompleto, correo, password, partes[5], partes[6], partes[7], antiguedad);
            }

            if (tipo == TipoUsuario.INSTRUCTOR && partes.length >= 7) {
                return new Instructor(nick, nombreCompleto, correo, password, partes[5], partes[6]);
            }

            if (tipo == TipoUsuario.ADMINISTRADOR && partes.length >= 6) {
                return new Administrador(nick, nombreCompleto, correo, password, partes[5]);
            }
        } catch (IllegalArgumentException e) {
            return null;
        }

        return null;
    }

    private int convertirEntero(String texto) {
        try {
            return Integer.parseInt(texto);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private String limpiar(String texto) {
        if (texto == null) {
            return "";
        }
        return texto.replace(";", ",").trim();
    }
}
