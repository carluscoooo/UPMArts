package upmarts.controlador;

import java.util.ArrayList;
import java.util.List;

import upmarts.integracion.IValidadorUPM;
import upmarts.modelo.EstudianteUPM;
import upmarts.modelo.Instructor;
import upmarts.modelo.ParticipanteExterno;
import upmarts.modelo.PersonalUPM;
import upmarts.modelo.Usuario;
import upmarts.persistencia.IAccesoUsuarios;

public class ControladorUsuarios implements IControladorUsuarios {

    private IAccesoUsuarios persistencia;
    private IValidadorUPM validadorUPM;
    private List<Usuario> usuarios;

    public ControladorUsuarios(IAccesoUsuarios persistencia, IValidadorUPM validadorUPM) {
        this.persistencia = persistencia;
        this.validadorUPM = validadorUPM;
        this.usuarios = persistencia.leerUsuarios();
    }

    public boolean registrarParticipanteExterno(String nombre, String nick, String correo,
                                                String pass, String dni, String tarjeta) {
        refrescarUsuarios();

        if (!validarDatosComunes(nombre, nick, correo, pass)) {
            return false;
        }

        if (esCorreoUPM(correo)) {
            return false;
        }

        if (!validarDNI(dni) || !validarTarjeta(tarjeta)) {
            return false;
        }

        String passwordCifrada = Usuario.cifrarPassword(pass);
        ParticipanteExterno participante = new ParticipanteExterno(nick, nombre, correo, passwordCifrada, dni, tarjeta);
        usuarios.add(participante);
        persistencia.guardarUsuarios(usuarios);
        return true;
    }

    public boolean registrarMiembroUPM(String nombre, String nick, String correo,
                                       String pass, String dni, String tipo, String datoExtra) {
        return registrarMiembroUPM(nombre, nick, correo, pass, dni, "NO_INDICADA", tipo, datoExtra);
    }

    public boolean registrarMiembroUPM(String nombre, String nick, String correo,
                                       String pass, String dni, String tarjeta, String tipo, String datoExtra) {
        refrescarUsuarios();

        if (!validarDatosComunes(nombre, nick, correo, pass)) {
            return false;
        }

        if (!esCorreoUPM(correo)) {
            return false;
        }

        if (!validadorUPM.verificarCredencialesUPM(correo, pass)) {
            return false;
        }

        if (!validarDNI(dni) || !validarTarjeta(tarjeta)) {
            return false;
        }

        String tipoNormalizado = normalizar(tipo);
        String passwordCifrada = Usuario.cifrarPassword(pass);

        if ("ESTUDIANTE".equals(tipoNormalizado)) {
            if (datoExtra == null || datoExtra.trim().isEmpty()) {
                return false;
            }

            EstudianteUPM estudiante = new EstudianteUPM(nick, nombre, correo, passwordCifrada, dni, tarjeta, datoExtra);
            usuarios.add(estudiante);
            persistencia.guardarUsuarios(usuarios);
            return true;
        }

        if ("PDI".equals(tipoNormalizado) || "PAS".equals(tipoNormalizado)) {
            int antiguedad = convertirEntero(datoExtra);

            if (antiguedad < 0) {
                return false;
            }

            PersonalUPM personal = new PersonalUPM(nick, nombre, correo, passwordCifrada, dni, tarjeta,
                    tipoNormalizado, antiguedad);
            usuarios.add(personal);
            persistencia.guardarUsuarios(usuarios);
            return true;
        }

        return false;
    }

    public boolean registrarInstructorUPM(String nombre, String nick, String correo,
                                          String pass, String dni, String iban) {
        refrescarUsuarios();

        if (!validarDatosComunes(nombre, nick, correo, pass)) {
            return false;
        }

        if (!validarDNI(dni) || !validarIBAN(iban)) {
            return false;
        }

        String passwordCifrada = Usuario.cifrarPassword(pass);
        Instructor instructor = new Instructor(nick, nombre, correo, passwordCifrada, dni, iban);
        usuarios.add(instructor);
        persistencia.guardarUsuarios(usuarios);
        return true;
    }

    public Usuario login(String correo, String pass) {
        refrescarUsuarios();

        if (correo == null || pass == null) {
            return null;
        }

        String passwordCifrada = Usuario.cifrarPassword(pass);

        for (Usuario usuario : usuarios) {
            if (usuario.getCorreoElectronico().equalsIgnoreCase(correo.trim())
                    && usuario.getContrasena().equals(passwordCifrada)) {
                return usuario;
            }
        }

        return null;
    }

    public List<Usuario> obtenerUsuarios() {
        refrescarUsuarios();
        return new ArrayList<Usuario>(usuarios);
    }

    private void refrescarUsuarios() {
        this.usuarios = persistencia.leerUsuarios();
    }

    private boolean validarDatosComunes(String nombre, String nick, String correo, String pass) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return false;
        }

        if (!Usuario.validarNick(nick)) {
            return false;
        }

        if (!Usuario.validarPassword(pass)) {
            return false;
        }

        if (!validarCorreo(correo)) {
            return false;
        }

        if (existeCorreo(correo) || existeNick(nick)) {
            return false;
        }

        return true;
    }

    private boolean validarCorreo(String correo) {
        if (correo == null) {
            return false;
        }

        String correoLimpio = correo.trim();
        return correoLimpio.contains("@") && correoLimpio.indexOf('@') > 0 && correoLimpio.indexOf('@') < correoLimpio.length() - 1;
    }

    private boolean existeCorreo(String correo) {
        for (Usuario usuario : usuarios) {
            if (usuario.getCorreoElectronico().equalsIgnoreCase(correo.trim())) {
                return true;
            }
        }
        return false;
    }

    private boolean existeNick(String nick) {
        for (Usuario usuario : usuarios) {
            if (usuario.getNombreUsuario().equalsIgnoreCase(nick.trim())) {
                return true;
            }
        }
        return false;
    }

    private boolean validarDNI(String dni) {
        if (dni == null) {
            return false;
        }
        return dni.trim().matches("[0-9]{8}[A-Za-z]");
    }

    private boolean validarTarjeta(String tarjeta) {
        if (tarjeta == null) {
            return false;
        }
        return tarjeta.trim().matches("[0-9]{8,19}") || "NO_INDICADA".equals(tarjeta);
    }

    private boolean validarIBAN(String iban) {
        if (iban == null) {
            return false;
        }
        return iban.trim().matches("[A-Za-z]{2}[0-9A-Za-z]{13,32}");
    }

    private boolean esCorreoUPM(String correo) {
        if (correo == null) {
            return false;
        }

        String correoNormalizado = correo.toLowerCase().trim();
        return correoNormalizado.endsWith("@upm.es") || correoNormalizado.endsWith("@alumnos.upm.es");
    }

    private int convertirEntero(String texto) {
        try {
            return Integer.parseInt(texto.trim());
        } catch (Exception e) {
            return -1;
        }
    }

    private String normalizar(String texto) {
        if (texto == null) {
            return "";
        }
        return texto.trim().toUpperCase();
    }
}
