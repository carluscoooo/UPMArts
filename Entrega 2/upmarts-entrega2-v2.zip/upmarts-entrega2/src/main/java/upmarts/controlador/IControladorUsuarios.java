package upmarts.controlador;

import java.util.List;
import upmarts.modelo.Usuario;

public interface IControladorUsuarios {

    boolean registrarParticipanteExterno(String nombre, String nick, String correo,
                                         String pass, String dni, String tarjeta);

    boolean registrarMiembroUPM(String nombre, String nick, String correo,
                                String pass, String dni, String tipo, String datoExtra);

    boolean registrarMiembroUPM(String nombre, String nick, String correo,
                                String pass, String dni, String tarjeta, String tipo, String datoExtra);

    boolean registrarInstructorUPM(String nombre, String nick, String correo,
                                   String pass, String dni, String iban);

    Usuario login(String correo, String pass);

    List<Usuario> obtenerUsuarios();
}
