package upmarts;

import java.util.List;
import java.util.Scanner;

import upmarts.controlador.ControladorUsuarios;
import upmarts.controlador.IControladorUsuarios;
import upmarts.integracion.AdaptadorLDAP;
import upmarts.integracion.IValidadorUPM;
import upmarts.modelo.Administrador;
import upmarts.modelo.TipoUsuario;
import upmarts.modelo.Usuario;
import upmarts.persistencia.GestorFicheroUsuarios;
import upmarts.persistencia.IAccesoUsuarios;
import upmarts.vista.IVistaUsuariosCLI;
import upmarts.vista.VistaPrincipalCLI;
import upmarts.vista.VistaUsuariosCLI;

public class App {

    public static void main(String[] args) {
        IAccesoUsuarios accesoUsuarios = new GestorFicheroUsuarios("data/usuarios.txt");
        crearAdministradorInicialSiNoExiste(accesoUsuarios);

        IValidadorUPM validadorUPM = new AdaptadorLDAP();
        IControladorUsuarios controladorUsuarios = new ControladorUsuarios(accesoUsuarios, validadorUPM);

        Scanner scanner = new Scanner(System.in);
        IVistaUsuariosCLI vistaUsuarios = new VistaUsuariosCLI(controladorUsuarios, scanner);
        VistaPrincipalCLI vistaPrincipal = new VistaPrincipalCLI(vistaUsuarios, scanner);

        vistaPrincipal.iniciarAplicacion();
        scanner.close();
    }

    private static void crearAdministradorInicialSiNoExiste(IAccesoUsuarios accesoUsuarios) {
        List<Usuario> usuarios = accesoUsuarios.leerUsuarios();

        for (Usuario usuario : usuarios) {
            if (usuario.getTipoUsuario() == TipoUsuario.ADMINISTRADOR) {
                return;
            }
        }

        String passwordCifrada = Usuario.cifrarPassword("Admin123456A");
        Administrador admin = new Administrador(
                "admin01",
                "Administrador Principal",
                "admin@upm.es",
                passwordCifrada,
                "910000000"
        );

        usuarios.add(admin);
        accesoUsuarios.guardarUsuarios(usuarios);
    }
}
