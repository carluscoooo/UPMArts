package upmarts.controlador;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.File;

import org.junit.Before;
import org.junit.Test;

import upmarts.integracion.IValidadorUPM;
import upmarts.persistencia.GestorFicheroUsuarios;
import upmarts.persistencia.IAccesoUsuarios;

public class ControladorUsuariosTest {

    private IControladorUsuarios controlador;
    private File ficheroTemporal;

    @Before
    public void preparar() throws Exception {
        ficheroTemporal = File.createTempFile("usuarios-test", ".txt");
        ficheroTemporal.deleteOnExit();

        IAccesoUsuarios acceso = new GestorFicheroUsuarios(ficheroTemporal.getAbsolutePath());
        IValidadorUPM validador = new IValidadorUPM() {
            public boolean verificarCredencialesUPM(String correo, String password) {
                return correo != null && correo.endsWith("@upm.es") && password != null && password.length() >= 12;
            }
        };

        controlador = new ControladorUsuarios(acceso, validador);
    }

    @Test
    public void registrarParticipanteExternoCorrectoDevuelveTrue() {
        boolean resultado = controlador.registrarParticipanteExterno(
                "Ana Externa", "ana01", "ana@gmail.com", "Password1234", "12345678A", "4111111111111111"
        );

        assertTrue(resultado);
    }

    @Test
    public void registrarParticipanteConPasswordInvalidaDevuelveFalse() {
        boolean resultado = controlador.registrarParticipanteExterno(
                "Ana Externa", "ana01", "ana@gmail.com", "corta", "12345678A", "4111111111111111"
        );

        assertFalse(resultado);
    }

    @Test
    public void loginConCredencialesCorrectasDevuelveUsuario() {
        controlador.registrarParticipanteExterno(
                "Ana Externa", "ana01", "ana@gmail.com", "Password1234", "12345678A", "4111111111111111"
        );

        assertNotNull(controlador.login("ana@gmail.com", "Password1234"));
    }

    @Test
    public void loginConCredencialesIncorrectasDevuelveNull() {
        controlador.registrarParticipanteExterno(
                "Ana Externa", "ana01", "ana@gmail.com", "Password1234", "12345678A", "4111111111111111"
        );

        assertNull(controlador.login("ana@gmail.com", "Password0000"));
    }

    @Test
    public void registrarMiembroUPMCorrectoDevuelveTrue() {
        boolean resultado = controlador.registrarMiembroUPM(
                "Luis UPM", "luis01", "luis@upm.es", "Password1234", "87654321B",
                "4111111111111111", "ESTUDIANTE", "M123456"
        );

        assertTrue(resultado);
    }

    @Test
    public void registrarParticipanteConNickConflictivoDevuelveFalse() {
        boolean resultado = controlador.registrarParticipanteExterno(
                "Usuario Root", "root", "root@gmail.com", "Password1234", "12345678A", "4111111111111111"
        );

        assertFalse(resultado);
    }

    @Test
    public void registrarParticipanteConNickConflictivoEnMayusculasDevuelveFalse() {
        boolean resultado = controlador.registrarParticipanteExterno(
                "Usuario Admin", "ADMIN", "admin@gmail.com", "Password1234", "12345678A", "4111111111111111"
        );

        assertFalse(resultado);
    }

}
